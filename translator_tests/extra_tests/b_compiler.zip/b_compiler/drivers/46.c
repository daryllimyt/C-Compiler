int fmain();

int main(){
    return ( (fmain() - 1) );
}