int fmain();

int main(){
    return (fmain() - 4);
}