int fmain();

int main(){
    return ( (fmain() - 0xFFFF0000) );
}