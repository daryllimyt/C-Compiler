int fmain();

int main(){
    return ( (fmain() - 0x15) );
}