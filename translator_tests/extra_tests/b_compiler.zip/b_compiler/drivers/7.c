int fmain();

int main(){
    return ( (fmain() - 9) );
}