int fmain(){
    int x = 5;
    x >>= 1;
    return x;
}