int fmain(){
    return sizeof(long);
}