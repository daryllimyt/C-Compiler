int fmain(){
    int x = 55;
    int y = 74;
    return x <= y;
}