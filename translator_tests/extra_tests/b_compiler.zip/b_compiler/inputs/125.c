int x = 5;

int fmain(){
    return x;
}