int fmain(){
    int x = 3;
    switch(5) x += 4;
    return x;
}