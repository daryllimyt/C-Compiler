int fmain(){
    int x = 3;
    int y = (x > 0) ? : 6;
    return y;
}