int fmain(){
    int x = -15;
    return !x;
}