int fmain(){
    int x = 1;
    int y = (x < 0)?: 4;
    return y;
}