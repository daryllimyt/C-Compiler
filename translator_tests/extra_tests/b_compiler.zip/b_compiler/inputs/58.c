int fmain(){
    int x = 5;
    if(false){
        x = 3;
    }
    else{
        x = 1;
    }
    return x;
}