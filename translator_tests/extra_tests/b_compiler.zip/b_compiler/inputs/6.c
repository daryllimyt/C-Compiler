int fmain(){
    int x = 10;
    x = 5;
    return x;
}