int fmain(){
    int x = 0;
    int y = 0;
    for(y = (15 - 5*2) >> 1; x > 0; x++){
        x += 1;
    }
    return y;
}