int fmain(){
    int x = 5;
    if(true){
        x = 3;
    }
    else{
        x = 1;
    }
    return x;
}