int fmain(){
    int x = 6 - 3;
    int y = 5;
    return y -x;
}