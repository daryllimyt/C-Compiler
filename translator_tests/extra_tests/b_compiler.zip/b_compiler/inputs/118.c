int fmain(){
    return sizeof(float);
}