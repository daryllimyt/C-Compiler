int fmain(){
    int x = 15^10;
    int y = 3;
    return x ^ y;
}