int f(int x, int y){
    return x + y;
}

int fmain(){
    int x = 1;
    int y = 2;
    return f(x,y);
}