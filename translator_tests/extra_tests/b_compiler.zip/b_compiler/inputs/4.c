int fmain(){
    int x = 4;
    int y = x;
    return y;
}