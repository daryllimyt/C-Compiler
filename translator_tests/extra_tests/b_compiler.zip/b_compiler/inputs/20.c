int fmain(){
    int x = 100/2;
    int y = 10;
    return x / y;
}