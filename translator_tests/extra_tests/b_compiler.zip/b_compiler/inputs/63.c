int f(){
    return 1;
}

int fmain(){
    return f();
}