int fmain(){
    int x = 5&13;
    int y = 3;
    return x&y;
}