int fmain(){
    int x = 5;
    if(true){
        x = 3;
    }
    if(false){
        x = 1;
    }
    return x;
}