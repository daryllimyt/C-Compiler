int f(){
    return 1;
}

int fmain(){
    return 2;
}

int g(){
    return 3;
}