int f(int x){
    return 1;
}

int fmain(){
    int x = 10;
    return f(x);
}