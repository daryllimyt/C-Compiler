int fmain(){
    int x = 2 + 3;
    int y = 5;
    return x + y;
}