int fmain(){
    int x = -1;
    int y = +3;
    return 2*y + -x;
}