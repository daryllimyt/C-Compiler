int fmain(){
    int x = 15;
    int y = x != 12;
    return (y != 0);
}