int fmain(){
    int x = 1;
    return 15 >> x;
}