int f(int a, int b, int c, int d, int e, int f, int g){
    return a + b + c + d + e + f + g;
}

int fmain(){
    int a = 1;
    int b = 2;
    int c = 3; 
    int d = 4;
    int e = 5;
    int f = 6;
    int g = 7;
    return f(a,b,c,d,e,f,g);
}