int fmain(){
    int x = 5;
    int y = --x;
    return x + y;
}