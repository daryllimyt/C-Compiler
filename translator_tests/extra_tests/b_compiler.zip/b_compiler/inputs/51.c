int fmain(){
    int x = 0xFFFF;
    return ~x;
}