int fmain(){
    int x = 10;
    for(int i = 0; i > x; i--){
        x += 1;
    }
    return x;
}