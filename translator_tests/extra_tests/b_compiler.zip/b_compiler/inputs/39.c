int fmain(){
    return true || true;
}