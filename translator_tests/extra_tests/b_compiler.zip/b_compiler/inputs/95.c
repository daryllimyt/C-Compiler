int x;

int fmain(){
    x = 2;
    return x;
}