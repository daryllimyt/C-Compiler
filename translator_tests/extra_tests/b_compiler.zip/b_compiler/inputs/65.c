int f(int x){
    return x;
}

int fmain(){
    int x = 1;
    return f(x);
}