int fmain(){
    int x = 0;
    switch(3){
        case(1): x += 1; break;
        case(2): x += 2; break;
        case(3): x += 3; break;
        case(4): x += 4; break;
        case(5): x += 5; break;
    }
    return x;
}