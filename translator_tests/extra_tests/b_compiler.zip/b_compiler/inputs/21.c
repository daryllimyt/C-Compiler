int fmain(){
    int x = 3%5;
    int y = 2;
    return x % y;
}