int fmain(){
    int x = 1;
    int y = (x > 0) ? 1 : 2;
    return y;
}