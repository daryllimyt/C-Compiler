int fmain(){
    return sizeof(double);
}