int fmain(){
    int x = 3;
    int y = 3;
    return x <= y;
}