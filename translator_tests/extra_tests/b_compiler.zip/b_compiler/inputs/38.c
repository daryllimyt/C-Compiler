int fmain(){
    return false || true;
}