int fmain(){
    int x = 5;
    int y = (x-5)? 3 : 2;
    return y;
}