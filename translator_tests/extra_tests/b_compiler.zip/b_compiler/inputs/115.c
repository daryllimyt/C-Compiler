int fmain(){
    int x = 0;
    return sizeof(x);
}