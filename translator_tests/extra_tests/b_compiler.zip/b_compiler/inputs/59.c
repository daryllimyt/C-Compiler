int fmain(){
    int x = 0;
    while(x < 5){
        x += 1;
    }
    return x;
}