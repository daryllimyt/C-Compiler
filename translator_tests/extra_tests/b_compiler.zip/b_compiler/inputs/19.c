int fmain(){
    int x = 2*4;
    int y = 2;
    return x*y;
}