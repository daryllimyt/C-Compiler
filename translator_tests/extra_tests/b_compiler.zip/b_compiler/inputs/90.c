int fmain(){
    int x = 2;
    int y = (x + 5) ?: 1;
    return y;
}