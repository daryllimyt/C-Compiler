int fmain(){
    return false || false;
}