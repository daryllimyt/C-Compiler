int fmain(){
    int x = 2;
    int y = sizeof(x += 52);
    return x;
}