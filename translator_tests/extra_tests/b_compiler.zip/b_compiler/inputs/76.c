int fmain(){
    int a = 1;
    // x = 32;
    int b = 2;
    /* int z;
    z = 51;
    x = 22;
    */
    int c = /*21 */ 3;
    /* int q = 40;
    x = 22; */ int d = 4;
    int e = 5; // + 9000
    int /* f = 5000 */ f = 6 /*
    faowneinc*/ ;
    return a+b+c+d+e+f;
}