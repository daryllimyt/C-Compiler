int fmain(){
    int x = 1;
    int y = ++x;
    return x + y;
}