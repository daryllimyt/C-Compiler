int fmain(){
    int x = 0;
    int y = 10;
    for(int y = 0; y < 5; y++){
        x += 1;
    }
    return y;
}