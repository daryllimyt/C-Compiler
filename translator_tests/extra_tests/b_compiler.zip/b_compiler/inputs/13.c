int fmain(){
    int x = 5;
    x &= 3;
    return x;
}