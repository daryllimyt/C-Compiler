int f(int x, int y, int z){
    return x + y + z;
}

int fmain(){
    int x = 1;
    int y = 2;
    int z = 3;
    return f(x,y,z);
}