int fmain(){
    int x = 3;
    do{
        x += 1;
    }while(x > 10);
    return x;
}