int fmain(){
    int x = 10;
    int y = 10;
    return x < y;
}