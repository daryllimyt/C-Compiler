int fmain(){
    int x = 0;
    switch(3){
        x += 10;
        case(1): x += 1;
        case(2): x += 2;
        case(3): x += 3;
    }
    return x;
}