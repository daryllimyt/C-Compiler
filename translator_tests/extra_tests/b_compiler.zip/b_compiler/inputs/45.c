int fmain(){
    return 5 || false;
}