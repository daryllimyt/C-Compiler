int fmain(){
    int x = 2;
    x *= 2;
    return x;
}