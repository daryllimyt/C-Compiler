int fmain(){
    int x = 0;
    for(int i = 0; i < 5; i++){
        x += 1;
    }
    return x;
}