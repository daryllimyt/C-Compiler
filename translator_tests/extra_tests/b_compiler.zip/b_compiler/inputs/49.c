int fmain(){
    int x = true;
    return !x;
}