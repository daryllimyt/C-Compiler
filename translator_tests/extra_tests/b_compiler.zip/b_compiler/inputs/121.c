int fmain(){
    return sizeof(short);
}