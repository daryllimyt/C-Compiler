int fmain(){
    int x = 15;
    x += 3;
    return x;
}