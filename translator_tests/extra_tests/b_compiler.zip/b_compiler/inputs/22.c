int fmain(){
    int x = 1|5;
    int y = 3;
    return x | y;
}