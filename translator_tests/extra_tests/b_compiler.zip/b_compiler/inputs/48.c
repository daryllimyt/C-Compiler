int fmain(){
    return !false;
}