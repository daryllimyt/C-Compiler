int fmain(){
    return sizeof(int);
}