int fmain(){
    int x = 15;
    do{
        x -= 1;
    }while(x > 9);
    return x;
}