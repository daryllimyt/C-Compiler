int fmain(){
    return 16 && 3;
}