int fmain(){
    int x = 5;
    int y = (x < 0) ? 1: 2;
    return y;
}