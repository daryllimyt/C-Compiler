int fmain(){
    return true && false;
}