int f(int x){
    x += 1;
    return x;
}

int fmain(){
    int x = 0;
    return f(x);
}