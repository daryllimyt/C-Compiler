int fmain(){
    int x = 3;
    x <<= 1;
    return x;
}