int fmain(){
    int x = 3;
    return x << 1;
}