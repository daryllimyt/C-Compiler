int fmain(){
    int x = 0;
    int y = 1;
    for(int i = 0; int j = y; i += x){
        x += 1;
        if(x >= 7){
            y = 0;
        }
    }
    return x;
}