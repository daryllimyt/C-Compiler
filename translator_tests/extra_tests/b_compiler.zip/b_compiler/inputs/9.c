int fmain(){
    int x = 6;
    x /= 2;
    return x;
}