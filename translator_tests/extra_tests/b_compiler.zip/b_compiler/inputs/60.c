int fmain(){
    int x = 9;
    while(x < 3){
        x -= 1;
    }
    return x;
}