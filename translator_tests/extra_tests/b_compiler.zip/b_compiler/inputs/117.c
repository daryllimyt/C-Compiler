int fmain(){
    return sizeof(char);
}