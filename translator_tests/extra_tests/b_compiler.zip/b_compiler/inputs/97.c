int fmain(){
    int x = 0;
    for(int i = 0; i <= 5; i++){
        x += i;
    }
    return x;
}