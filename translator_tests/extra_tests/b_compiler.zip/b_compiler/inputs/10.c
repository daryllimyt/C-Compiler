int fmain(){
    int x = 17;
    x %= 2;
    return x;
}