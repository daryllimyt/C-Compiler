int fmain(){
    int x = 31;
    int y = 12;
    return x >= y;
}