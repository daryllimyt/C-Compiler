int fmain(){
    return sizeof(bool);
}