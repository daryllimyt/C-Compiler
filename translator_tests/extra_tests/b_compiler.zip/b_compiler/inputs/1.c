int fmain(){
    return 1;
}