int f(int a, int b, int c, int d){
    return a + b + c + d;
}

int fmain(){
    int a = 1;
    int b = 2;
    int c = 3;
    int d = 4;
    return a + b + c + d;
}